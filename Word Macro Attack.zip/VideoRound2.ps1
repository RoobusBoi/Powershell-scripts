﻿Add-Type -AssemblyName presentationCore
Add-Type -AssemblyName System.Windows.Forms

$way = [Environment]::GetFolderPath("MyPictures")
$way2 = "$way\image.jpg"
$urlimage = "https://drive.google.com/uc?export=download&id=1XGdhbgjOfUp_3OPxZEOG38mKXIOovCDL"


Invoke-WebRequest $urlimage -OutFile $way2


$Form = New-Object System.Windows.Forms.Form
$Form.ControlBox = $False
$Form.Text = "Hentai Is Cool"
$Form.Width = 1920
$Form.Height = 1080
$Form.Cursor=[System.Windows.Forms.Cursors]::WaitCursor
$image = [System.Drawing.Image]::Fromfile($way2)    
$pictureBox = new-object Windows.Forms.PictureBox
$pictureBox.width=1920
$pictureBox.height= 1080
$pictureBox.top=0
$pictureBox.left=0
$pictureBox.Image=$image
$Button2 = New-Object System.Windows.Forms.Button
$Button2.Text = "Pls sex me"
$Button2.Width = 1000
$Button2.Height = 130
$Button2.Location = New-Object System.Drawing.Point(105,700)
$Button2.Font = "Microsoft Sans Serif,36"
$Null = $Form.Controls.Add($Button2)
$Button3 = New-Object System.Windows.Forms.Button
$Button3.Text = "Exit"
$Button3.Width = 1000
$Button3.Height = 130
$Button3.Location = New-Object System.Drawing.Point(105,888)
$Button3.Font = "Microsoft Sans Serif,36"
$Null = $Form.Controls.Add($Button3)
$Form.Controls.add($pictureBox)
$Form.Add_Shown({$Form.Activate()})
$Null = $Form.ShowDialog()