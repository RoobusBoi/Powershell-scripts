# web-credential-password-attack
numberic and dictionary attack to web auterntication creds like wifi routers
